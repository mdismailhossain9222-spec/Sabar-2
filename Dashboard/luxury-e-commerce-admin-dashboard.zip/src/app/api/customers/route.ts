import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/db-init";

export async function POST(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();

    const [created] = await db
      .insert(customers)
      .values({
        name: body.name,
        email: body.email,
        phone: body.phone || "+971 50 000 0000",
        emirate: body.emirate || "Dubai",
        address: body.address || "Jumeirah 1, Dubai",
        vipTier: body.vipTier || "Couture Privé",
        totalSpent: String(body.totalSpent ?? 0),
        ordersCount: Number(body.ordersCount ?? 0),
        preferredSize: body.preferredSize || "M",
        notes: body.notes || "",
      })
      .returning();

    return NextResponse.json({
      customer: {
        id: created.id,
        name: created.name,
        email: created.email,
        phone: created.phone,
        emirate: created.emirate,
        address: created.address,
        vipTier: created.vipTier as "Couture Privé" | "Gold Circle" | "Atelier Member",
        totalSpent: Number(created.totalSpent),
        ordersCount: created.ordersCount,
        preferredSize: created.preferredSize,
        notes: created.notes,
      },
    });
  } catch (error) {
    console.error("Error in POST /api/customers:", error);
    return NextResponse.json({ error: "Failed to create customer" }, { status: 500 });
  }
}
