import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, orders, customers, atelierSettings } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/db-init";
import { desc } from "drizzle-orm";
import {
  INITIAL_PRODUCTS,
  INITIAL_ORDERS,
  INITIAL_CUSTOMERS,
  REVENUE_CHART_DATA,
  EMIRATE_DISTRIBUTION_BASE,
} from "@/lib/seed-data";

export async function GET() {
  try {
    await ensureDbSeeded();

    const [dbProducts, dbOrders, dbCustomers, dbSettings] = await Promise.all([
      db.select().from(products).orderBy(desc(products.id)),
      db.select().from(orders).orderBy(desc(orders.orderDate)),
      db.select().from(customers).orderBy(desc(customers.totalSpent)),
      db.select().from(atelierSettings).limit(1),
    ]);

    const formattedProducts = dbProducts.map((p) => ({
      id: p.id,
      sku: p.sku,
      name: p.name,
      collection: p.collection,
      category: p.category,
      price: Number(p.price),
      stock: p.stock,
      stockStatus: p.stockStatus as "In Stock" | "Low Stock" | "Sold Out",
      image: p.image,
      fabric: p.fabric,
      sizes: Array.isArray(p.sizes) ? p.sizes : ["S", "M", "L"],
      description: p.description,
      featured: p.featured,
    }));

    const formattedOrders = dbOrders.map((o) => ({
      id: o.id,
      orderNumber: o.orderNumber,
      customerName: o.customerName,
      customerEmail: o.customerEmail,
      customerPhone: o.customerPhone,
      shippingAddress: o.shippingAddress,
      emirate: o.emirate as
        | "Dubai"
        | "Abu Dhabi"
        | "Sharjah"
        | "Ras Al Khaimah"
        | "Ajman"
        | "Fujairah",
      totalAmount: Number(o.totalAmount),
      status: o.status as "Pending" | "Shipped" | "Delivered",
      paymentMethod: o.paymentMethod,
      courierService: o.courierService,
      notes: o.notes,
      items: o.items,
      orderDate: o.orderDate.toISOString(),
    }));

    const formattedCustomers = dbCustomers.map((c) => ({
      id: c.id,
      name: c.name,
      email: c.email,
      phone: c.phone,
      emirate: c.emirate,
      address: c.address,
      vipTier: c.vipTier as "Couture Privé" | "Gold Circle" | "Atelier Member",
      totalSpent: Number(c.totalSpent),
      ordersCount: c.ordersCount,
      preferredSize: c.preferredSize,
      notes: c.notes,
    }));

    return NextResponse.json({
      products: formattedProducts.length ? formattedProducts : INITIAL_PRODUCTS,
      orders: formattedOrders.length ? formattedOrders : INITIAL_ORDERS,
      customers: formattedCustomers.length ? formattedCustomers : INITIAL_CUSTOMERS,
      settings: dbSettings[0] ?? {
        id: 1,
        maisonName: "Sabr By Simran",
        creativeDirector: "Simran Kaur",
        atelierLocation: "Villa 14, Al Wasl Road, Jumeirah 1, Dubai, UAE",
        conciergeEmail: "prive@sabrbysimran.ae",
        conciergePhone: "+971 4 589 2400",
        currency: "AED",
        complimentaryChauffeurThreshold: 3000,
        lowStockThreshold: 5,
        vipAutoUpgradeThreshold: 15000,
        enableWhatsAppConcierge: true,
        enableBespokeMeasurements: true,
      },
      revenueChartData: REVENUE_CHART_DATA,
      emirateBase: EMIRATE_DISTRIBUTION_BASE,
    });
  } catch (error) {
    console.error("Error in GET /api/dashboard:", error);
    return NextResponse.json({
      products: INITIAL_PRODUCTS,
      orders: INITIAL_ORDERS,
      customers: INITIAL_CUSTOMERS,
      settings: {
        id: 1,
        maisonName: "Sabr By Simran",
        creativeDirector: "Simran Kaur",
        atelierLocation: "Villa 14, Al Wasl Road, Jumeirah 1, Dubai, UAE",
        conciergeEmail: "prive@sabrbysimran.ae",
        conciergePhone: "+971 4 589 2400",
        currency: "AED",
        complimentaryChauffeurThreshold: 3000,
        lowStockThreshold: 5,
        vipAutoUpgradeThreshold: 15000,
        enableWhatsAppConcierge: true,
        enableBespokeMeasurements: true,
      },
      revenueChartData: REVENUE_CHART_DATA,
      emirateBase: EMIRATE_DISTRIBUTION_BASE,
    });
  }
}
