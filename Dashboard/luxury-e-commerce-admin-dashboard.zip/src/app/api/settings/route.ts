import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { atelierSettings } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/db-init";
import { eq } from "drizzle-orm";

export async function PATCH(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();
    const existing = await db.select().from(atelierSettings).limit(1);

    if (existing.length === 0) {
      const [created] = await db.insert(atelierSettings).values(body).returning();
      return NextResponse.json({ settings: created });
    }

    const [updated] = await db
      .update(atelierSettings)
      .set({
        maisonName: body.maisonName,
        creativeDirector: body.creativeDirector,
        atelierLocation: body.atelierLocation,
        conciergeEmail: body.conciergeEmail,
        conciergePhone: body.conciergePhone,
        currency: body.currency,
        complimentaryChauffeurThreshold: Number(body.complimentaryChauffeurThreshold),
        lowStockThreshold: Number(body.lowStockThreshold),
        vipAutoUpgradeThreshold: Number(body.vipAutoUpgradeThreshold),
        enableWhatsAppConcierge: Boolean(body.enableWhatsAppConcierge),
        enableBespokeMeasurements: Boolean(body.enableBespokeMeasurements),
        updatedAt: new Date(),
      })
      .where(eq(atelierSettings.id, existing[0].id))
      .returning();

    return NextResponse.json({ settings: updated });
  } catch (error) {
    console.error("Error in PATCH /api/settings:", error);
    return NextResponse.json({ error: "Failed to update settings" }, { status: 500 });
  }
}
