import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/db-init";
import { eq } from "drizzle-orm";

export async function PATCH(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();
    const { id, status, notes, courierService } = body;

    if (!id) {
      return NextResponse.json({ error: "Order ID is required" }, { status: 400 });
    }

    const updateValues: Record<string, unknown> = {};
    if (status) updateValues.status = status;
    if (typeof notes === "string") updateValues.notes = notes;
    if (courierService) updateValues.courierService = courierService;

    const [updated] = await db
      .update(orders)
      .set(updateValues)
      .where(eq(orders.id, Number(id)))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    return NextResponse.json({
      order: {
        id: updated.id,
        orderNumber: updated.orderNumber,
        customerName: updated.customerName,
        customerEmail: updated.customerEmail,
        customerPhone: updated.customerPhone,
        shippingAddress: updated.shippingAddress,
        emirate: updated.emirate,
        totalAmount: Number(updated.totalAmount),
        status: updated.status,
        paymentMethod: updated.paymentMethod,
        courierService: updated.courierService,
        notes: updated.notes,
        items: updated.items,
        orderDate: updated.orderDate.toISOString(),
      },
    });
  } catch (error) {
    console.error("Error in PATCH /api/orders:", error);
    return NextResponse.json({ error: "Failed to update order" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();
    const randomSuffix = Math.floor(9483 + Math.random() * 500);
    const orderNumber = body.orderNumber || `SBS-${randomSuffix}`;

    const [inserted] = await db
      .insert(orders)
      .values({
        orderNumber,
        customerName: body.customerName,
        customerEmail: body.customerEmail || "client@privé.ae",
        customerPhone: body.customerPhone || "+971 50 000 0000",
        shippingAddress: body.shippingAddress || "Jumeirah 1, Dubai, UAE",
        emirate: body.emirate || "Dubai",
        totalAmount: String(body.totalAmount || 4850),
        status: body.status || "Pending",
        paymentMethod: body.paymentMethod || "Amex Centurion •••• 1004",
        courierService: body.courierService || "Sabr White-Glove Chauffeur",
        notes: body.notes || "",
        items: body.items || [],
        orderDate: new Date(),
      })
      .returning();

    return NextResponse.json({
      order: {
        id: inserted.id,
        orderNumber: inserted.orderNumber,
        customerName: inserted.customerName,
        customerEmail: inserted.customerEmail,
        customerPhone: inserted.customerPhone,
        shippingAddress: inserted.shippingAddress,
        emirate: inserted.emirate,
        totalAmount: Number(inserted.totalAmount),
        status: inserted.status,
        paymentMethod: inserted.paymentMethod,
        courierService: inserted.courierService,
        notes: inserted.notes,
        items: inserted.items,
        orderDate: inserted.orderDate.toISOString(),
      },
    });
  } catch (error) {
    console.error("Error in POST /api/orders:", error);
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 });
  }
}
