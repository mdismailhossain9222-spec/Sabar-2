import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/db-init";
import { eq } from "drizzle-orm";

function computeStockStatus(stock: number): "In Stock" | "Low Stock" | "Sold Out" {
  if (stock <= 0) return "Sold Out";
  if (stock <= 5) return "Low Stock";
  return "In Stock";
}

export async function POST(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();
    const stockNum = Number(body.stock ?? 8);
    const stockStatus = computeStockStatus(stockNum);
    const sku =
      body.sku ||
      `SBS-AW26-${String(Math.floor(100 + Math.random() * 899)).padStart(3, "0")}`;

    const [created] = await db
      .insert(products)
      .values({
        sku,
        name: body.name,
        collection: body.collection || "Nocturne d'Or AW26",
        category: body.category || "Couture Abayas",
        price: String(body.price || 4950),
        stock: stockNum,
        stockStatus,
        image: body.image || "/images/garment-1.jpg",
        fabric: body.fabric || "100% Mulberry Silk & Hand Zardozi",
        sizes: Array.isArray(body.sizes) ? body.sizes : ["S", "M", "L", "Custom"],
        description:
          body.description ||
          "Hand-finished in our Dubai atelier using archival couture techniques and pure natural silks.",
        featured: Boolean(body.featured ?? true),
      })
      .returning();

    return NextResponse.json({
      product: {
        id: created.id,
        sku: created.sku,
        name: created.name,
        collection: created.collection,
        category: created.category,
        price: Number(created.price),
        stock: created.stock,
        stockStatus: created.stockStatus as "In Stock" | "Low Stock" | "Sold Out",
        image: created.image,
        fabric: created.fabric,
        sizes: created.sizes,
        description: created.description,
        featured: created.featured,
      },
    });
  } catch (error) {
    console.error("Error in POST /api/products:", error);
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();
    const { id, stock, price, name, category, collection, fabric, description } = body;

    if (!id) {
      return NextResponse.json({ error: "Product ID is required" }, { status: 400 });
    }

    const updateValues: Record<string, unknown> = {};
    if (typeof stock === "number") {
      const clamped = Math.max(0, stock);
      updateValues.stock = clamped;
      updateValues.stockStatus = computeStockStatus(clamped);
    }
    if (typeof price === "number") updateValues.price = String(price);
    if (name) updateValues.name = name;
    if (category) updateValues.category = category;
    if (collection) updateValues.collection = collection;
    if (fabric) updateValues.fabric = fabric;
    if (description) updateValues.description = description;

    const [updated] = await db
      .update(products)
      .set(updateValues)
      .where(eq(products.id, Number(id)))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    return NextResponse.json({
      product: {
        id: updated.id,
        sku: updated.sku,
        name: updated.name,
        collection: updated.collection,
        category: updated.category,
        price: Number(updated.price),
        stock: updated.stock,
        stockStatus: updated.stockStatus as "In Stock" | "Low Stock" | "Sold Out",
        image: updated.image,
        fabric: updated.fabric,
        sizes: updated.sizes,
        description: updated.description,
        featured: updated.featured,
      },
    });
  } catch (error) {
    console.error("Error in PATCH /api/products:", error);
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "Product ID is required" }, { status: 400 });
    }

    await db.delete(products).where(eq(products.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error in DELETE /api/products:", error);
    return NextResponse.json({ error: "Failed to delete product" }, { status: 500 });
  }
}
